<?php

namespace App\Interfaces\admin;

interface CmsPageRepositoryInterface
{
    public function CmsUpdate(array $data);
}
