<footer class="main-footer">
    <strong>Copyright &copy; {{date('Y')}} <a href="{{ route('admin.dashboard') }}">{{ config('app.name') }}</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
</footer>