<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Maintenance Mode</title>
</head>
<body>
<div class="container">
    <div style="margin-top: 50px; text-align: center">
        We will be up in couple of minutes. Thanks for patience.
    </div>
</div>
</body>
</html>
